package com.sparklix.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SparklixUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparklixUserServiceApplication.class, args);
	}

}
